var searchData=
[
  ['use_5fdebug',['USE_DEBUG',['../buddy_8c.html#a260e435d62aa44fda8a1368df99c4a89',1,'buddy.c']]]
];
