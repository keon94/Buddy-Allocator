var searchData=
[
  ['page_5fsize',['PAGE_SIZE',['../buddy_8c.html#a7d467c1d283fdfa1f2081ba1e0d01b6e',1,'buddy.c']]],
  ['page_5fto_5faddr',['PAGE_TO_ADDR',['../buddy_8c.html#a7c13b46aacf7af9976a7f058076c81a3',1,'buddy.c']]],
  ['pdebug',['PDEBUG',['../buddy_8c.html#a9077500d1488a75e4eec5eeb1131655e',1,'buddy.c']]]
];
